package time_data_structures;

public class FileFormatException extends Exception {
	

		
		public FileFormatException() {
			super();
		}
		
		/**
		 * @param s
		 */
		public FileFormatException(String s) {
			super();
		}
	}